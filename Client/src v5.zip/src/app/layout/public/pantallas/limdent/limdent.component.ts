import { Component } from '@angular/core';

@Component({
  selector: 'app-limdent',
  templateUrl: './limdent.component.html',
  styleUrls: ['./limdent.component.scss']
})
export class LimdentComponent {

}
