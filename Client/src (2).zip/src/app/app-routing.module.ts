import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './layout/public/pantallas/home/home.component';
import { LoginComponent } from './layout/public/pantallas/login/login.component';
import { CitasComponent } from './layout/public/pantallas/citas/citas.component';
import { TestimoniosComponent} from './layout/public/pantallas/testimonios/testimonios.component'
import { TratamientosComponent } from './layout/public/pantallas/tratamientos/tratamientos.component'
import { ErrorComponent } from './layout/public/pantallas/error/error.component';
import { MapasitioComponent } from './layout/public/pantallas/mapasitio/mapasitio.component';
import { RegistroComponent } from './layout/public/pantallas/registro/registro.component';
import { McitasComponent } from './layout/public/sidenavbar/mcitas/mcitas.component';
import { HmedicoComponent } from './layout/public/sidenavbar/hmedico/hmedico.component';
import { InperfilComponent } from './layout/public/sidenavbar/inperfil/inperfil.component';

const routes: Routes = [
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'citas',
    component: CitasComponent
  },
  {
    path: 'testimonios',
    component:TestimoniosComponent

  },
  {
    path: 'tratamientos',
    component:TratamientosComponent

  },
  {
    path: 'error',
    component:ErrorComponent

  },
  {
    path: 'mapasitio',
    component:MapasitioComponent

  },
  {
    path: 'registro',
    component:RegistroComponent

  },
  {
    path: 'mcitas',
    component:McitasComponent

  },
  {
    path: 'hmedico',
    component:HmedicoComponent

  }
  ,
  {
    path: 'inperfil',
    component:InperfilComponent

  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
