import { Component } from '@angular/core';

@Component({
  selector: 'app-clientescitas',
  templateUrl: './clientescitas.component.html',
  styleUrls: ['./clientescitas.component.scss']
})
export class ClientescitasComponent {

}
