import { Component } from '@angular/core';

@Component({
  selector: 'app-inperfil',
  templateUrl: './inperfil.component.html',
  styleUrls: ['./inperfil.component.scss']
})
export class InperfilComponent {

}
