import { Component } from '@angular/core';

@Component({
  selector: 'app-mcitas',
  templateUrl: './mcitas.component.html',
  styleUrls: ['./mcitas.component.scss']
})
export class McitasComponent {

}
