
import { Component } from '@angular/core';

@Component({
  selector: 'app-horarionav',
  templateUrl: './horarionav.component.html',
  styleUrls: ['./horarionav.component.scss']
})
export class HorarionavComponent {

}
