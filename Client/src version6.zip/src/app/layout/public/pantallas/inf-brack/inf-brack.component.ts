import { Component } from '@angular/core';

@Component({
  selector: 'app-inf-brack',
  templateUrl: './inf-brack.component.html',
  styleUrls: ['./inf-brack.component.scss']
})
export class InfBrackComponent {

}
