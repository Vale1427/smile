import { Component } from '@angular/core';

@Component({
  selector: 'app-avisopriv',
  templateUrl: './avisopriv.component.html',
  styleUrls: ['./avisopriv.component.scss']
})
export class AvisoprivComponent {

}
