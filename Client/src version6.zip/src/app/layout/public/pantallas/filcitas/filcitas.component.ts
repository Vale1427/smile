import { Component } from '@angular/core';

@Component({
  selector: 'app-filcitas',
  templateUrl: './filcitas.component.html',
  styleUrls: ['./filcitas.component.scss']
})
export class FilcitasComponent {

}
