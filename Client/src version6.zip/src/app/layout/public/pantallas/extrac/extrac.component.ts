import { Component } from '@angular/core';

@Component({
  selector: 'app-extrac',
  templateUrl: './extrac.component.html',
  styleUrls: ['./extrac.component.scss']
})
export class ExtracComponent {

}
