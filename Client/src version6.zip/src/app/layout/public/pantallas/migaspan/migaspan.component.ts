import { Component } from '@angular/core';

@Component({
  selector: 'app-migaspan',
  templateUrl: './migaspan.component.html',
  styleUrls: ['./migaspan.component.scss']
})
export class MigaspanComponent {

}
