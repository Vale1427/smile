import { Component } from '@angular/core';

@Component({
  selector: 'app-muelas',
  templateUrl: './muelas.component.html',
  styleUrls: ['./muelas.component.scss']
})
export class MuelasComponent {

}
