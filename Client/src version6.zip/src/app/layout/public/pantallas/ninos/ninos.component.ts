import { Component } from '@angular/core';

@Component({
  selector: 'app-ninos',
  templateUrl: './ninos.component.html',
  styleUrls: ['./ninos.component.scss']
})
export class NinosComponent {

}
