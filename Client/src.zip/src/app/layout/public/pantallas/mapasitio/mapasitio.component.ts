import { Component } from '@angular/core';

@Component({
  selector: 'app-mapasitio',
  templateUrl: './mapasitio.component.html',
  styleUrls: ['./mapasitio.component.scss']
})
export class MapasitioComponent {

}
