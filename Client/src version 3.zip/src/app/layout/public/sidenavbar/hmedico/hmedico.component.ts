import { Component } from '@angular/core';

@Component({
  selector: 'app-hmedico',
  templateUrl: './hmedico.component.html',
  styleUrls: ['./hmedico.component.scss']
})
export class HmedicoComponent {

}
