import { Component } from '@angular/core';

@Component({
  selector: 'app-editarcita',
  templateUrl: './editarcita.component.html',
  styleUrls: ['./editarcita.component.scss']
})
export class EditarcitaComponent {

}
